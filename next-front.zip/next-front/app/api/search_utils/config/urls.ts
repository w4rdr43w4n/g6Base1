
const urls = {
  backendUrl:"http://51.20.165.45"
}

const endpoints = {
  literature:"literature/",
  documentation:"documentation/",
  plagiarism:"plagiarism/",
  article:"article/",
  outline:"outline/"
}

const URLS = {
  'urls':urls,
  'endpoints':endpoints
}

export default URLS