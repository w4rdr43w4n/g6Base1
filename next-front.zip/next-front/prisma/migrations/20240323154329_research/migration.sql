-- DropIndex
DROP INDEX "Research_email_key";
