-- AlterTable
ALTER TABLE "User" ALTER COLUMN "isVerified" SET DEFAULT false;
