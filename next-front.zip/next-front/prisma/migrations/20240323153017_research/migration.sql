-- DropIndex
DROP INDEX "Research_username_key";
